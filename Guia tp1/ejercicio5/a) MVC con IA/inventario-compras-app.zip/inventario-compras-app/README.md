# Inventario Compras App — Spring Boot + Spring Data JPA + Thymeleaf

Sistema de gestión de stock y compras a proveedores mayoristas, construido
con **Spring Boot 3**, **Spring MVC**, **Spring Data JPA** y **Thymeleaf**,
sobre la plantilla visual **Spark Admin**.

## Regla de negocio central

- Una **Orden de Compra** se crea en estado `PENDIENTE` y **no** afecta el
  stock todavía.
- Al marcarla como **`RECIBIDA`** (botón "Recibir Orden"):
  - El `stockActual` de cada producto del detalle se incrementa
    (`stockActual += cantidad`).
  - El `precioCosto` del producto se actualiza con el precio unitario de
    esa compra.
  - Todo ocurre dentro de **una única transacción** (`@Transactional`):
    si un ítem falla, se revierte todo (rollback completo).
- Una orden **`RECIBIDA`** queda **bloqueada**: ya no se puede editar ni
  cancelar. Solo las órdenes `PENDIENTE` admiten "Recibir" o "Cancelar".

## Cómo ejecutar

Requisitos: JDK 17+ y Maven 3.8+.

```bash
cd inventario-compras-app
mvn spring-boot:run
```

Disponible en <http://localhost:8080> (redirige automáticamente a `/dashboard`).

- `/dashboard` — indicadores clave (stock crítico, órdenes pendientes, valor de inventario)
- `/productos` — catálogo con alertas de stock mínimo
- `/ordenes` — listado de órdenes con acciones "Recibir" / "Cancelar"
- `/ordenes/nueva` — alta de una nueva orden (maestro-detalle)
- `/h2-console` — consola H2 (`jdbc:h2:mem:inventariodb`, usuario `sa`, sin contraseña)

El proyecto incluye `data.sql` con proveedores, productos (algunos ya en
stock crítico a propósito) y dos órdenes de ejemplo (una `PENDIENTE` y
una `RECIBIDA`), para poder probar el flujo de inmediato sin cargar datos
manualmente.

Empaquetar como `.jar`:

```bash
mvn clean package
java -jar target/inventario-compras-app.jar
```

## Estructura del proyecto

```
inventario-compras-app/
├── pom.xml
├── README.md
├── src/
│   ├── main/
│   │   ├── java/com/inventario/app/
│   │   │   ├── InventarioComprasApplication.java   # Clase de arranque
│   │   │   │
│   │   │   ├── controller/
│   │   │   │   ├── DashboardController.java         # GET /dashboard (KPIs)
│   │   │   │   ├── ProductoController.java          # GET /productos
│   │   │   │   └── OrdenCompraController.java       # /ordenes (listar, crear, recibir, cancelar)
│   │   │   │
│   │   │   ├── service/
│   │   │   │   ├── ProveedorService.java / impl/ProveedorServiceImpl.java
│   │   │   │   ├── ProductoService.java  / impl/ProductoServiceImpl.java
│   │   │   │   └── OrdenCompraService.java / impl/OrdenCompraServiceImpl.java   # Lógica transaccional de recepción
│   │   │   │
│   │   │   ├── repository/
│   │   │   │   ├── ProveedorRepository.java
│   │   │   │   ├── ProductoRepository.java          # incluye @Query de stock crítico y valor de inventario
│   │   │   │   ├── OrdenCompraRepository.java
│   │   │   │   └── DetalleOrdenCompraRepository.java
│   │   │   │
│   │   │   ├── model/
│   │   │   │   ├── Proveedor.java
│   │   │   │   ├── Producto.java
│   │   │   │   ├── OrdenCompra.java                 # @OneToMany hacia sus detalles
│   │   │   │   ├── DetalleOrdenCompra.java          # @ManyToOne hacia OrdenCompra y Producto
│   │   │   │   └── enums/{EstadoOrdenCompra, EstadoProveedor}.java
│   │   │   │
│   │   │   └── dto/
│   │   │       ├── OrdenCompraDTO.java               # cabecera + lista de detalles (validación en cascada)
│   │   │       └── DetalleOrdenCompraDTO.java
│   │   │
│   │   └── resources/
│   │       ├── application.properties                # H2, JPA, carga de data.sql
│   │       ├── data.sql                               # datos de ejemplo
│   │       ├── static/{css,js,libs,images}            # recursos de Spark Admin
│   │       └── templates/
│   │           ├── fragments/layout.html              # sidebar/navbar/mensajes reutilizables
│   │           ├── dashboard.html                     # basada en index.html
│   │           ├── productos/lista.html               # basada en tables-basic.html
│   │           └── ordenes/{lista.html, formulario.html}  # formulario.html basado en ui-forms.html
│   │
│   └── test/java/com/inventario/app/                  # (paquete reservado para pruebas)
```

## Notas de diseño

- **BigDecimal** para todos los valores monetarios (nunca `double`/`float`),
  evitando errores de redondeo en precios y totales.
- **Fragmentos Thymeleaf** (`fragments/layout.html`) para no repetir el
  sidebar/navbar en cada una de las 4 vistas.
- El **formulario de nueva orden** permite agregar filas dinámicamente por
  JavaScript (clonando la última fila y reindexando sus atributos
  `name`), pero el **subtotal/total mostrado en el navegador es solo
  informativo**: el cálculo autoritativo siempre ocurre en
  `OrdenCompraServiceImpl`, del lado del servidor.
- Todo el código Java incluye comentarios extensos explicando el rol de
  cada capa, cada anotación (`@Entity`, `@OneToMany`, `@Transactional`,
  `@Valid`, `@ModelAttribute`, `@PathVariable`, etc.) y el paso a paso de
  la lógica de recepción de mercadería.
