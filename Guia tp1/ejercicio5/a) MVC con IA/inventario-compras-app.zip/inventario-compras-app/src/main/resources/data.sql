-- ============================================================================
-- data.sql
-- ============================================================================
-- Spring Boot ejecuta automáticamente este script al arrancar la
-- aplicación (una vez que Hibernate ya creó el esquema, gracias a
-- spring.jpa.defer-datasource-initialization=true), precargando algunos
-- datos de ejemplo para poder probar el flujo completo de compras de
-- inmediato: ver proveedores activos en el <select> del formulario, ver
-- productos con distintos niveles de stock (algunos ya en estado
-- crítico) y ver algunas órdenes de compra ya cargadas con distintos
-- estados en el listado.
-- ============================================================================

-- ------------------------------------------------------------------------
-- PROVEEDORES
-- ------------------------------------------------------------------------
INSERT INTO proveedores (id, cuit, razon_social, telefono, correo_contacto, estado) VALUES
  (1, '30-71234567-9', 'TechImport S.A.',        '+54 11 4555-0101', 'ventas@techimport.com',   'ACTIVO'),
  (2, '30-70987654-3', 'Mayorista Andina SRL',   '+54 261 420-2020', 'contacto@andinasrl.com',  'ACTIVO'),
  (3, '30-69876543-1', 'Global Components LTDA', '+54 11 4777-3030', 'compras@globalcomp.com',  'ACTIVO'),
  (4, '30-68765432-0', 'Distribuidora del Sur',  '+54 351 400-4040', 'info@distrisur.com',      'INACTIVO');

-- ------------------------------------------------------------------------
-- PRODUCTOS
-- ------------------------------------------------------------------------
-- Se cargan productos con distintas combinaciones de stockActual /
-- stockMinimo a propósito: algunos por encima del mínimo (estado normal)
-- y otros por debajo o igual (estado de stock crítico), para poder
-- verificar visualmente ambas alertas en productos/lista.html y en el
-- dashboard sin necesidad de cargar datos manualmente.
INSERT INTO productos (id, codigo_sku, nombre, descripcion, categoria, precio_venta, precio_costo, stock_actual, stock_minimo) VALUES
  (1, 'NB-LEN-X1',   'Notebook Lenovo ThinkPad X1',      'Notebook ultraliviana 14" Core i7, 16GB RAM',  'Notebooks',    2450000.00, 1980000.00, 3,  5),
  (2, 'MON-DELL-27', 'Monitor Dell 27" 4K',                'Monitor IPS 27 pulgadas resolución 4K',        'Monitores',     650000.00,  510000.00, 12, 4),
  (3, 'TEC-LOG-MX',  'Teclado Mecánico Logitech MX',      'Teclado mecánico inalámbrico retroiluminado',  'Periféricos',   180000.00,  130000.00, 2,  8),
  (4, 'MOU-LOG-G3',  'Mouse Gamer Logitech G302',          'Mouse óptico gamer 6 botones programables',    'Periféricos',    85000.00,   58000.00, 40, 10),
  (5, 'SSD-SAM-1TB', 'SSD Samsung 970 EVO 1TB',            'Disco de estado sólido NVMe 1TB',              'Almacenamiento', 210000.00, 165000.00, 6,  10),
  (6, 'RAM-COR-16',  'Memoria RAM Corsair Vengeance 16GB', 'Módulo RAM DDR4 16GB 3200MHz',                 'Componentes',   120000.00,   95000.00, 25, 8),
  (7, 'GPU-RTX-4060','Placa de Video RTX 4060',            'Placa de video 8GB GDDR6',                     'Componentes',  1150000.00,  950000.00, 1,  3),
  (8, 'IMP-EPS-L3250','Impresora Multifunción Epson L3250','Impresora multifunción con sistema continuo',  'Impresoras',    380000.00,  310000.00, 9,  5);

-- ------------------------------------------------------------------------
-- ÓRDENES DE COMPRA DE EJEMPLO
-- ------------------------------------------------------------------------
-- Una orden PENDIENTE (aún no impacta stock) y una orden ya RECIBIDA
-- (representa una compra ya procesada anteriormente), para poder ver de
-- inmediato ambos estados con sus respectivos badges y comportamientos
-- de bloqueo en ordenes/lista.html.
INSERT INTO ordenes_compra (id, numero_orden, fecha_emision, proveedor_id, estado, total) VALUES
  (1, 'ORD-000001', CURRENT_DATE - 10, 1, 'RECIBIDA', 1980000.00),
  (2, 'ORD-000002', CURRENT_DATE,      2, 'PENDIENTE',  650000.00);

INSERT INTO detalles_orden_compra (id, orden_compra_id, producto_id, cantidad_solicitada, precio_unitario_compra, subtotal) VALUES
  (1, 1, 1, 1, 1980000.00, 1980000.00),
  (2, 2, 2, 1,  650000.00,  650000.00);

-- Ajuste de las secuencias de autoincremento de H2 para que las próximas
-- filas insertadas DESDE LA APLICACIÓN (a través de Hibernate) continúen
-- a partir del siguiente id disponible, evitando colisiones con los ids
-- fijos ya usados arriba para los datos de ejemplo.
ALTER TABLE proveedores ALTER COLUMN id RESTART WITH 5;
ALTER TABLE productos ALTER COLUMN id RESTART WITH 9;
ALTER TABLE ordenes_compra ALTER COLUMN id RESTART WITH 3;
ALTER TABLE detalles_orden_compra ALTER COLUMN id RESTART WITH 3;
