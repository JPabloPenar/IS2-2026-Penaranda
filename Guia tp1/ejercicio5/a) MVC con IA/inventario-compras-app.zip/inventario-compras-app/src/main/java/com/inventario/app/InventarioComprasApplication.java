package com.inventario.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * ============================================================================
 * InventarioComprasApplication
 * ============================================================================
 * Punto de entrada ("entry point") de la aplicación. Contiene el método
 * main() que la JVM ejecuta al lanzar el .jar.
 *
 * @SpringBootApplication combina:
 *   - @Configuration: permite que esta clase (y las anotadas con @Bean en
 *     general) definan beans para el contenedor de Spring.
 *   - @EnableAutoConfiguration: Spring Boot inspecciona las dependencias
 *     presentes en el classpath (spring-boot-starter-web,
 *     spring-boot-starter-data-jpa, H2, etc.) y configura automáticamente
 *     el servidor Tomcat embebido, el DataSource, el EntityManager de
 *     JPA/Hibernate, el motor de plantillas Thymeleaf, entre otros.
 *   - @ComponentScan: escanea este paquete (com.inventario.app) y todos
 *     sus subpaquetes (controller, service, repository, model, dto)
 *     buscando clases anotadas con @Component/@Service/@Repository/
 *     @Controller para registrarlas automáticamente en el contenedor de
 *     Spring (el "ApplicationContext").
 * ============================================================================
 */
@SpringBootApplication
public class InventarioComprasApplication {

    /**
     * SpringApplication.run(...) crea el ApplicationContext, ejecuta la
     * auto-configuración, levanta el servidor web embebido en el puerto
     * configurado (application.properties) y deja la aplicación
     * escuchando peticiones HTTP.
     */
    public static void main(String[] args) {
        SpringApplication.run(InventarioComprasApplication.class, args);
    }
}
