package com.inventario.app.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.math.BigDecimal;

/**
 * ============================================================================
 * Producto (Entidad JPA)
 * ============================================================================
 * Representa un artículo de tecnología comercializado por la empresa, con
 * su información comercial (precios) y de inventario (stock).
 *
 * @Entity:
 *   Marca la clase como una entidad persistente de JPA: Hibernate la
 *   reconoce y gestiona automáticamente una tabla de base de datos
 *   asociada, mapeando cada campo a una columna.
 *
 * @Table(name = "productos"):
 *   Nombre explícito de la tabla (buena práctica frente a dejar que
 *   Hibernate infiera el nombre a partir del nombre de la clase).
 * ============================================================================
 */
@Entity
@Table(name = "productos")
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Código SKU (Stock Keeping Unit): identificador único de inventario
     * usado internamente por la empresa para distinguir cada artículo,
     * independientemente de su nombre comercial.
     */
    @Column(name = "codigo_sku", nullable = false, unique = true, length = 40)
    private String codigoSku;

    @Column(nullable = false, length = 150)
    private String nombre;

    @Column(length = 500)
    private String descripcion;

    @Column(length = 80)
    private String categoria;

    /**
     * Se utiliza BigDecimal (en lugar de double/float) para representar
     * TODOS los valores monetarios de la aplicación (precios, subtotales,
     * totales). Esto es una práctica estándar de la industria: los tipos
     * de punto flotante binario (double/float) no pueden representar con
     * exactitud la mayoría de los valores decimales (por ejemplo, 0.1 en
     * binario es un número periódico), lo que introduce errores de
     * redondeo acumulativos inaceptables al trabajar con dinero.
     * BigDecimal, en cambio, representa los números decimales de forma
     * exacta.
     *
     * precision = 12, scale = 2: hasta 12 dígitos en total, 2 de ellos
     * decimales (equivalente a admitir montos de hasta 9.999.999.999,99).
     */
    @Column(name = "precio_venta", nullable = false, precision = 12, scale = 2)
    private BigDecimal precioVenta;

    /**
     * Precio de costo actual del producto. Este valor se actualiza
     * automáticamente cada vez que se recibe una orden de compra que
     * incluya este producto (ver
     * OrdenCompraServiceImpl.recibirOrden(...)), reflejando siempre el
     * último precio pagado al proveedor.
     */
    @Column(name = "precio_costo", nullable = false, precision = 12, scale = 2)
    private BigDecimal precioCosto;

    /**
     * Cantidad de unidades actualmente disponibles en depósito. Se
     * incrementa automáticamente al recibir una orden de compra; en un
     * sistema completo también se decrementaría al confirmarse ventas
     * (fuera del alcance de este proyecto).
     */
    @Column(name = "stock_actual", nullable = false)
    private Integer stockActual;

    /**
     * Umbral mínimo de stock configurado para este producto. Cuando
     * stockActual cae por debajo (o igual) de este valor, el producto se
     * considera en "stock crítico" y debe alertarse visualmente en el
     * listado de productos y contabilizarse en el dashboard.
     */
    @Column(name = "stock_minimo", nullable = false)
    private Integer stockMinimo;

    public Producto() {
    }

    public Producto(String codigoSku, String nombre, String descripcion, String categoria,
                     BigDecimal precioVenta, BigDecimal precioCosto, Integer stockActual, Integer stockMinimo) {
        this.codigoSku = codigoSku;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.categoria = categoria;
        this.precioVenta = precioVenta;
        this.precioCosto = precioCosto;
        this.stockActual = stockActual;
        this.stockMinimo = stockMinimo;
    }

    /**
     * Método de conveniencia de LECTURA (no persistido en la base de
     * datos: no lleva ninguna anotación JPA) que encapsula la regla de
     * negocio "¿este producto está en stock crítico?". Se expone como un
     * método de la propia entidad porque es una regla que depende
     * exclusivamente de los datos del propio Producto, no de ninguna otra
     * colaboración externa, y así se evita repetir la misma comparación
     * "stockActual <= stockMinimo" en varios lugares del código (vistas,
     * servicios).
     *
     * Al seguir la convención de nombres "isXxx()", tanto Thymeleaf
     * (${producto.stockCritico}) como cualquier librería basada en la
     * convención JavaBean pueden invocarlo como si fuera una propiedad
     * más del objeto.
     */
    public boolean isStockCritico() {
        if (stockActual == null || stockMinimo == null) {
            return false;
        }
        return stockActual <= stockMinimo;
    }

    // ==========================================================================
    // GETTERS Y SETTERS
    // ==========================================================================

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCodigoSku() {
        return codigoSku;
    }

    public void setCodigoSku(String codigoSku) {
        this.codigoSku = codigoSku;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public BigDecimal getPrecioVenta() {
        return precioVenta;
    }

    public void setPrecioVenta(BigDecimal precioVenta) {
        this.precioVenta = precioVenta;
    }

    public BigDecimal getPrecioCosto() {
        return precioCosto;
    }

    public void setPrecioCosto(BigDecimal precioCosto) {
        this.precioCosto = precioCosto;
    }

    public Integer getStockActual() {
        return stockActual;
    }

    public void setStockActual(Integer stockActual) {
        this.stockActual = stockActual;
    }

    public Integer getStockMinimo() {
        return stockMinimo;
    }

    public void setStockMinimo(Integer stockMinimo) {
        this.stockMinimo = stockMinimo;
    }
}
