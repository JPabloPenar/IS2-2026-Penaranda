package com.inventario.app.service.impl;

import com.inventario.app.model.Proveedor;
import com.inventario.app.model.enums.EstadoProveedor;
import com.inventario.app.repository.ProveedorRepository;
import com.inventario.app.service.ProveedorService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.NoSuchElementException;

/**
 * ============================================================================
 * ProveedorServiceImpl
 * ============================================================================
 * Implementación de la lógica de negocio (aquí bastante sencilla, de tipo
 * "consulta") relacionada con proveedores.
 *
 * @Service: especialización de @Component que marca esta clase como un
 * bean de la capa de SERVICIO, distinguiéndola semánticamente de los
 * @Repository (acceso a datos) y @Controller (capa web).
 * ============================================================================
 */
@Service
public class ProveedorServiceImpl implements ProveedorService {

    private final ProveedorRepository proveedorRepository;

    /** Inyección de dependencias por constructor (recomendada en Spring moderno). */
    public ProveedorServiceImpl(ProveedorRepository proveedorRepository) {
        this.proveedorRepository = proveedorRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Proveedor> listarTodos() {
        return proveedorRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Proveedor> listarActivos() {
        return proveedorRepository.findByEstado(EstadoProveedor.ACTIVO);
    }

    @Override
    @Transactional(readOnly = true)
    public Proveedor buscarPorId(Long id) {
        return proveedorRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("No existe un proveedor con id: " + id));
    }
}
