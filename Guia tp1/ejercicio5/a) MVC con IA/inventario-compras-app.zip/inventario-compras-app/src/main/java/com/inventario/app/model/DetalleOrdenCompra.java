package com.inventario.app.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.math.BigDecimal;

/**
 * ============================================================================
 * DetalleOrdenCompra (Entidad JPA - Línea de detalle del maestro-detalle)
 * ============================================================================
 * Representa UNA línea dentro de una OrdenCompra: "se solicitaron N
 * unidades del Producto P a tal precio unitario". Es la entidad "detalle"
 * en la relación maestro-detalle con OrdenCompra.
 * ============================================================================
 */
@Entity
@Table(name = "detalles_orden_compra")
public class DetalleOrdenCompra {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Lado "dueño" de la relación con OrdenCompra: esta entidad es la que
     * físicamente contiene la columna de clave foránea "orden_compra_id"
     * en su tabla. Ver la explicación completa de "mappedBy" en el
     * atributo "detalles" de OrdenCompra.java para entender cómo ambos
     * lados de la relación se complementan.
     *
     * fetch = FetchType.LAZY: no es necesario cargar los datos completos
     * de la orden cabecera cada vez que se trabaja con un detalle
     * individual (por ejemplo, durante el recorrido de detalles en
     * recibirOrden(...), donde lo que interesa es el Producto asociado,
     * no la propia orden).
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "orden_compra_id", nullable = false)
    private OrdenCompra ordenCompra;

    /**
     * @ManyToOne hacia Producto:
     *   MUCHOS DetalleOrdenCompra (de distintas órdenes, o incluso de la
     *   misma orden en distintas líneas si se permitiera) pueden hacer
     *   referencia al mismo Producto.
     *
     * fetch = FetchType.LAZY: el acceso al producto se realiza
     * explícitamente cuando se necesita (por ejemplo, para actualizar su
     * stock al recibir la orden, o para mostrar su nombre en la vista de
     * detalle).
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "producto_id", nullable = false)
    private Producto producto;

    @Column(name = "cantidad_solicitada", nullable = false)
    private Integer cantidadSolicitada;

    /**
     * Precio unitario de COMPRA acordado con el proveedor para esta línea
     * (puede diferir del precioCosto histórico que el Producto tenía
     * hasta ese momento). Al recibirse la orden, este valor pasa a
     * convertirse en el nuevo precioCosto "oficial" del producto (ver
     * OrdenCompraServiceImpl.recibirOrden).
     */
    @Column(name = "precio_unitario_compra", nullable = false, precision = 12, scale = 2)
    private BigDecimal precioUnitarioCompra;

    /**
     * Subtotal de esta línea = cantidadSolicitada * precioUnitarioCompra.
     * Se calcula y asigna explícitamente en la capa de servicio (no se
     * recalcula automáticamente por Hibernate) para que quede persistido
     * de forma explícita y auditable en la base de datos.
     */
    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal subtotal;

    public DetalleOrdenCompra() {
    }

    public DetalleOrdenCompra(Producto producto, Integer cantidadSolicitada, BigDecimal precioUnitarioCompra) {
        this.producto = producto;
        this.cantidadSolicitada = cantidadSolicitada;
        this.precioUnitarioCompra = precioUnitarioCompra;
        this.subtotal = precioUnitarioCompra.multiply(BigDecimal.valueOf(cantidadSolicitada));
    }

    // ==========================================================================
    // GETTERS Y SETTERS
    // ==========================================================================

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public OrdenCompra getOrdenCompra() {
        return ordenCompra;
    }

    public void setOrdenCompra(OrdenCompra ordenCompra) {
        this.ordenCompra = ordenCompra;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public Integer getCantidadSolicitada() {
        return cantidadSolicitada;
    }

    public void setCantidadSolicitada(Integer cantidadSolicitada) {
        this.cantidadSolicitada = cantidadSolicitada;
    }

    public BigDecimal getPrecioUnitarioCompra() {
        return precioUnitarioCompra;
    }

    public void setPrecioUnitarioCompra(BigDecimal precioUnitarioCompra) {
        this.precioUnitarioCompra = precioUnitarioCompra;
    }

    public BigDecimal getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(BigDecimal subtotal) {
        this.subtotal = subtotal;
    }
}
