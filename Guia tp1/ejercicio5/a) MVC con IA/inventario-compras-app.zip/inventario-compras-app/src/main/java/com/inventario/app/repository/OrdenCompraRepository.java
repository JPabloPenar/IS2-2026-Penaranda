package com.inventario.app.repository;

import com.inventario.app.model.OrdenCompra;
import com.inventario.app.model.enums.EstadoOrdenCompra;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * ============================================================================
 * OrdenCompraRepository
 * ============================================================================
 * Capa de acceso a datos para la entidad OrdenCompra (cabecera del
 * documento maestro-detalle).
 * ============================================================================
 */
@Repository
public interface OrdenCompraRepository extends JpaRepository<OrdenCompra, Long> {

    /**
     * Lista todas las órdenes ordenadas de la más reciente a la más
     * antigua según su fecha de emisión, utilizada para el listado
     * principal de órdenes de compra (ordenes/lista.html). El sufijo
     * "OrderByFechaEmisionDesc" es interpretado automáticamente por
     * Spring Data JPA para agregar "ORDER BY fecha_emision DESC" a la
     * consulta generada.
     */
    List<OrdenCompra> findAllByOrderByFechaEmisionDesc();

    /**
     * Cuenta cuántas órdenes se encuentran actualmente en un estado
     * determinado. Se utiliza en el dashboard para mostrar el indicador
     * "Órdenes Pendientes" (contarPorEstado(EstadoOrdenCompra.PENDIENTE)).
     */
    long countByEstado(EstadoOrdenCompra estado);
}
