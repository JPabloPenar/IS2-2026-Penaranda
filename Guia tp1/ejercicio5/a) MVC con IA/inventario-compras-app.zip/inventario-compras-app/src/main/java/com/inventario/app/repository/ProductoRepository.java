package com.inventario.app.repository;

import com.inventario.app.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

/**
 * ============================================================================
 * ProductoRepository
 * ============================================================================
 * Capa de acceso a datos para la entidad Producto.
 * ============================================================================
 */
@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {

    boolean existsByCodigoSku(String codigoSku);

    /**
     * @Query:
     *   Cuando la consulta que se necesita es más compleja de lo que un
     *   simple "método de consulta derivado" (basado en el nombre del
     *   método) puede expresar, se puede escribir explícitamente en JPQL
     *   (Java Persistence Query Language: un lenguaje de consultas muy
     *   similar a SQL, pero que opera sobre ENTIDADES y sus propiedades
     *   Java, no directamente sobre tablas y columnas físicas de la base
     *   de datos).
     *
     *   "SELECT p FROM Producto p WHERE p.stockActual <= p.stockMinimo":
     *   Selecciona todos los productos cuyo stock actual está en el
     *   umbral crítico o por debajo de él, aplicando directamente en la
     *   base de datos la misma regla de negocio que expone
     *   Producto.isStockCritico(), pero de forma eficiente (sin tener que
     *   traer TODOS los productos a memoria para luego filtrarlos "a
     *   mano" en Java).
     *
     *   Se utiliza tanto en productos/lista.html (para resaltar los
     *   productos críticos) como en el cálculo del indicador del
     *   dashboard "cantidad de productos en stock crítico".
     */
    @Query("SELECT p FROM Producto p WHERE p.stockActual <= p.stockMinimo")
    List<Producto> findProductosConStockCritico();

    /**
     * Variante de la consulta anterior que solo necesita el CONTEO de
     * productos en stock crítico (usada en la tarjeta indicadora del
     * dashboard), evitando traer las entidades completas a memoria
     * cuando solo se necesita un número.
     */
    @Query("SELECT COUNT(p) FROM Producto p WHERE p.stockActual <= p.stockMinimo")
    long contarProductosConStockCritico();

    /**
     * Calcula el VALOR TOTAL del inventario actual, entendido como la
     * sumatoria, para cada producto, de (precioCosto * stockActual).
     *
     * COALESCE(..., 0): función estándar de SQL/JPQL que devuelve el
     * primer valor no nulo de la lista de argumentos. Se utiliza aquí
     * porque una función de agregación como SUM(...) devuelve NULL (no
     * cero) cuando la tabla está completamente vacía (no hay productos
     * cargados todavía); COALESCE evita que el dashboard reciba un valor
     * null inesperado en ese escenario, devolviendo 0 en su lugar.
     */
    @Query("SELECT COALESCE(SUM(p.precioCosto * p.stockActual), 0) FROM Producto p")
    BigDecimal calcularValorTotalInventario();
}
