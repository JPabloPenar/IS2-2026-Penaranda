package com.inventario.app.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================================
 * OrdenCompraDTO
 * ============================================================================
 * DTO "maestro" que representa la totalidad del formulario de creación de
 * una nueva orden de compra: los datos de cabecera (proveedor, fecha) más
 * la lista completa de líneas de detalle (DetalleOrdenCompraDTO).
 *
 * Este es el objeto que Spring MVC completa automáticamente (data
 * binding) a partir de TODOS los campos del formulario HTML enviado por
 * POST, incluyendo los campos indexados de la tabla de detalle
 * (th:field="*{detalles[0].productoId}", "*{detalles[1].productoId}",
 * etc.), gracias a que Spring sabe interpretar la sintaxis
 * "nombrePropiedad[indice].subPropiedad" en los "name" de los inputs HTML
 * y mapearla automáticamente contra una List<DetalleOrdenCompraDTO>.
 * ============================================================================
 */
public class OrdenCompraDTO {

    /**
     * Id del Proveedor elegido en el <select> del formulario.
     * @NotNull: es obligatorio seleccionar un proveedor para poder crear
     * la orden.
     */
    @NotNull(message = "Debe seleccionar un proveedor")
    private Long proveedorId;

    /**
     * Fecha de emisión de la orden. Se precarga por defecto con la fecha
     * actual desde el controlador (ver OrdenCompraController.nuevaOrden),
     * pero el usuario puede modificarla si lo desea.
     */
    @NotNull(message = "La fecha de emisión es obligatoria")
    private LocalDate fechaEmision;

    /**
     * Lista de líneas de detalle del formulario.
     *
     * @Valid en este campo (además del @Valid que se coloca sobre el
     * propio OrdenCompraDTO en la firma del método del controlador) es lo
     * que le indica a Spring que, al validar el objeto OrdenCompraDTO
     * completo, TAMBIÉN debe "descender" y validar automáticamente cada
     * elemento individual de esta lista contra las anotaciones declaradas
     * en DetalleOrdenCompraDTO (este mecanismo se conoce como "validación
     * en cascada"). Sin esta anotación, Spring solo validaría los campos
     * directos de OrdenCompraDTO (proveedorId, fechaEmision) e ignoraría
     * por completo las validaciones de cada fila de detalle.
     */
    @Valid
    private List<DetalleOrdenCompraDTO> detalles = new ArrayList<>();

    public OrdenCompraDTO() {
    }

    public Long getProveedorId() {
        return proveedorId;
    }

    public void setProveedorId(Long proveedorId) {
        this.proveedorId = proveedorId;
    }

    public LocalDate getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(LocalDate fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public List<DetalleOrdenCompraDTO> getDetalles() {
        return detalles;
    }

    public void setDetalles(List<DetalleOrdenCompraDTO> detalles) {
        this.detalles = detalles;
    }
}
