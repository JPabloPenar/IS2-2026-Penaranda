package com.inventario.app.controller;

import com.inventario.app.service.ProductoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * ============================================================================
 * ProductoController
 * ============================================================================
 * Controlador responsable de mostrar el catálogo de productos junto con
 * su información de inventario y las alertas de stock mínimo.
 * ============================================================================
 */
@Controller
public class ProductoController {

    private final ProductoService productoService;

    public ProductoController(ProductoService productoService) {
        this.productoService = productoService;
    }

    /**
     * Muestra el listado completo de productos.
     *
     * La vista productos/lista.html decide, POR CADA FILA, si el producto
     * debe resaltarse como "en stock crítico" consultando directamente el
     * método de conveniencia producto.isStockCritico() (expuesto por la
     * propia entidad Producto), sin que el controlador tenga que separar
     * manualmente los productos en dos listas distintas.
     */
    @GetMapping("/productos")
    public String listarProductos(Model model) {
        model.addAttribute("productos", productoService.listarTodos());
        return "productos/lista";
    }
}
