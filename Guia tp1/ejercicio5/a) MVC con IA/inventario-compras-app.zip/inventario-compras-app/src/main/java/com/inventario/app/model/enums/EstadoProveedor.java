package com.inventario.app.model.enums;

/**
 * ============================================================================
 * EstadoProveedor (Enumeración)
 * ============================================================================
 * Representa si un Proveedor se encuentra habilitado o no para realizarle
 * nuevas órdenes de compra. Se modela como enum (en lugar de un simple
 * booleano "activo") para mantener consistencia con EstadoOrdenCompra y
 * dejar la puerta abierta a futuros estados intermedios (por ejemplo,
 * "SUSPENDIDO") sin tener que rediseñar el modelo de datos.
 * ============================================================================
 */
public enum EstadoProveedor {

    /** El proveedor puede ser seleccionado para crear nuevas órdenes de compra. */
    ACTIVO,

    /**
     * El proveedor está deshabilitado: no debe aparecer como opción al
     * crear una nueva orden de compra, aunque sus datos y su historial de
     * órdenes pasadas se conservan intactos.
     */
    INACTIVO
}
