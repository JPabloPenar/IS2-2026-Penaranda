package com.inventario.app.controller;

import com.inventario.app.service.OrdenCompraService;
import com.inventario.app.service.ProductoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * ============================================================================
 * DashboardController
 * ============================================================================
 * Controlador de la pantalla principal del sistema: muestra un resumen
 * ejecutivo del estado del inventario y de las compras mediante
 * indicadores clave (KPIs).
 * ============================================================================
 */
@Controller
public class DashboardController {

    private final ProductoService productoService;
    private final OrdenCompraService ordenCompraService;

    public DashboardController(ProductoService productoService, OrdenCompraService ordenCompraService) {
        this.productoService = productoService;
        this.ordenCompraService = ordenCompraService;
    }

    /**
     * Calcula y muestra los tres indicadores clave solicitados:
     *   1) Cantidad de productos en stock crítico.
     *   2) Cantidad de órdenes de compra actualmente PENDIENTES.
     *   3) Valor monetario total del inventario actual.
     *
     * Cada indicador se calcula delegando en el método específico del
     * servicio correspondiente, manteniendo la lógica de cálculo fuera
     * del controlador (que solo debe orquestar la llamada a los
     * servicios y volcar sus resultados al modelo para la vista).
     */
    @GetMapping({"/", "/dashboard"})
    public String mostrarDashboard(Model model) {

        // Indicador 1: cantidad de productos con stock en o por debajo
        // del mínimo configurado.
        long cantidadStockCritico = productoService.contarStockCritico();

        // Indicador 2: cantidad de órdenes de compra todavía no recibidas
        // ni canceladas (requieren seguimiento). El cálculo se delega
        // enteramente en la capa de servicio (contarPendientes), que a su
        // vez se apoya en una consulta derivada del repositorio
        // (countByEstado), evitando traer todas las órdenes a memoria
        // solo para contarlas.
        long cantidadOrdenesPendientes = ordenCompraService.contarPendientes();

        // Indicador 3: valor total del inventario (precioCosto * stockActual
        // sumado sobre todos los productos).
        var valorInventario = productoService.calcularValorTotalInventario();

        model.addAttribute("cantidadStockCritico", cantidadStockCritico);
        model.addAttribute("cantidadOrdenesPendientes", cantidadOrdenesPendientes);
        model.addAttribute("valorInventario", valorInventario);

        // Se agregan también los productos en stock crítico (una vista
        // resumida, no la lista completa) para mostrarlos como alerta
        // rápida directamente en el dashboard.
        model.addAttribute("productosStockCritico", productoService.listarStockCritico());

        return "dashboard";
    }
}
