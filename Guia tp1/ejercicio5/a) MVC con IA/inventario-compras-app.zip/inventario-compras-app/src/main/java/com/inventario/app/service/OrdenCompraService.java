package com.inventario.app.service;

import com.inventario.app.dto.OrdenCompraDTO;
import com.inventario.app.model.OrdenCompra;

import java.util.List;

/**
 * ============================================================================
 * OrdenCompraService (Interfaz)
 * ============================================================================
 * Contrato de la capa de negocio para el ciclo de vida completo de una
 * orden de compra: creación, consulta, recepción de mercadería y
 * cancelación. Es la interfaz más importante del proyecto, ya que
 * concentra las reglas de negocio centrales solicitadas en el enunciado
 * (actualización transaccional de stock al recibir una orden, bloqueo de
 * órdenes ya recibidas, etc.).
 * ============================================================================
 */
public interface OrdenCompraService {

    /** Devuelve todas las órdenes de compra, de la más reciente a la más antigua. */
    List<OrdenCompra> listarTodas();

    /**
     * Cantidad de órdenes de compra que se encuentran actualmente en
     * estado PENDIENTE (usado como indicador clave en el dashboard).
     */
    long contarPendientes();

    /** Busca una orden de compra por su id, lanzando una excepción si no existe. */
    OrdenCompra buscarPorId(Long id);

    /**
     * Crea una nueva orden de compra a partir de los datos capturados en
     * el formulario maestro-detalle (OrdenCompraDTO).
     *
     * Responsabilidades esperadas de la implementación:
     *   - Descartar las filas de detalle que el usuario dejó vacías.
     *   - Resolver cada productoId del DTO hacia su entidad Producto real.
     *   - Calcular el subtotal de cada línea y el total de la orden.
     *   - Generar un número de orden legible (ej. "ORD-000001").
     *   - Crear la orden en estado PENDIENTE (sin afectar el stock todavía).
     *
     * @param dto datos ya validados del formulario de nueva orden
     * @return la OrdenCompra recién creada y persistida
     */
    OrdenCompra crearOrden(OrdenCompraDTO dto);

    /**
     * Confirma la recepción de la mercadería de una orden PENDIENTE:
     * incrementa el stock de cada producto involucrado, actualiza su
     * precio de costo y transiciona la orden al estado RECIBIDA. Debe
     * ejecutarse de forma estrictamente transaccional (todo o nada).
     *
     * @param id id de la orden de compra a recibir
     * @return la OrdenCompra ya actualizada en estado RECIBIDA
     * @throws IllegalStateException si la orden no se encuentra en estado
     *         PENDIENTE (una orden ya RECIBIDA o CANCELADA no puede
     *         volver a recibirse)
     */
    OrdenCompra recibirOrden(Long id);

    /**
     * Cancela una orden que todavía se encuentra PENDIENTE. No afecta el
     * stock de ningún producto (porque el stock solo se modifica al
     * RECIBIR una orden, nunca al crearla).
     *
     * @param id id de la orden de compra a cancelar
     * @return la OrdenCompra ya actualizada en estado CANCELADA
     * @throws IllegalStateException si la orden no se encuentra en estado
     *         PENDIENTE (por ejemplo, si ya fue RECIBIDA, queda bloqueada
     *         y no puede cancelarse retroactivamente)
     */
    OrdenCompra cancelarOrden(Long id);
}
