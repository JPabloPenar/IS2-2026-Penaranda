package com.inventario.app.model;

import com.inventario.app.model.enums.EstadoOrdenCompra;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================================
 * OrdenCompra (Entidad JPA - Cabecera del documento maestro-detalle)
 * ============================================================================
 * Representa el documento de una orden de compra emitida a un Proveedor
 * para reponer stock. Es la entidad "maestra" en la relación
 * maestro-detalle con DetalleOrdenCompra (cada orden puede tener varias
 * líneas de detalle, una por cada producto solicitado).
 * ============================================================================
 */
@Entity
@Table(name = "ordenes_compra")
public class OrdenCompra {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Número de orden legible para humanos (por ejemplo "ORD-000001"),
     * distinto del "id" técnico autogenerado. Se genera automáticamente en
     * OrdenCompraServiceImpl al crear la orden, combinando un prefijo fijo
     * con el id autogenerado.
     */
    @Column(name = "numero_orden", nullable = false, unique = true, length = 30)
    private String numeroOrden;

    @Column(name = "fecha_emision", nullable = false)
    private LocalDate fechaEmision;

    /**
     * @ManyToOne:
     *   Declara el lado "muchos" de una relación uno-a-muchos: MUCHAS
     *   OrdenCompra pueden estar asociadas a UN mismo Proveedor. Es la
     *   relación inversa/complementaria de un eventual
     *   @OneToMany en la entidad Proveedor (que en este proyecto no se
     *   modela explícitamente porque no es necesario navegar "de
     *   Proveedor hacia sus Órdenes" en ninguna pantalla, pero la relación
     *   en la base de datos sigue existiendo igualmente mediante la clave
     *   foránea).
     *
     * fetch = FetchType.LAZY:
     *   Le indica a Hibernate que NO cargue automáticamente los datos
     *   completos del Proveedor asociado cada vez que se recupera una
     *   OrdenCompra desde la base de datos; solo se cargan cuando el
     *   código realmente accede a orden.getProveedor().algúnDato() (carga
     *   "perezosa"/bajo demanda). Esto mejora el rendimiento cuando se listan
     *   muchas órdenes y no siempre se necesita el detalle completo del
     *   proveedor de cada una.
     *
     * @JoinColumn(name = "proveedor_id"):
     *   Especifica el nombre de la columna de clave foránea que se crea en
     *   la tabla "ordenes_compra" para materializar esta relación
     *   (ordenes_compra.proveedor_id -> proveedores.id).
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "proveedor_id", nullable = false)
    private Proveedor proveedor;

    /**
     * Estado actual de la orden (PENDIENTE / RECIBIDA / CANCELADA). Ver
     * EstadoOrdenCompra para el detalle completo de las transiciones
     * válidas.
     */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private EstadoOrdenCompra estado;

    /**
     * Monto total de la orden, calculado como la suma de los subtotales
     * de todas sus líneas de detalle. Se recalcula en la capa de servicio
     * cada vez que se crea o modifica la orden (ver
     * OrdenCompraServiceImpl.crearOrden(...)), NUNCA se confía en un valor
     * de total enviado directamente desde el formulario del cliente.
     */
    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal total;

    /**
     * @OneToMany(mappedBy = "ordenCompra", ...):
     *   Declara el lado "uno" de la relación uno-a-muchos: UNA OrdenCompra
     *   tiene MUCHOS DetalleOrdenCompra.
     *
     *   mappedBy = "ordenCompra": indica que la relación NO es dueña de la
     *   clave foránea (la tabla "ordenes_compra" no tiene ninguna columna
     *   apuntando a los detalles); es la entidad DetalleOrdenCompra la que
     *   posee físicamente la columna de clave foránea "orden_compra_id"
     *   (ver el atributo "ordenCompra" en esa clase, mapeado con
     *   @ManyToOne). "mappedBy" simplemente le dice a Hibernate: "esta es
     *   la relación inversa/de solo lectura de la relación ya declarada en
     *   el otro lado".
     *
     *   cascade = CascadeType.ALL: cualquier operación de persistencia
     *   realizada sobre la OrdenCompra (guardar, actualizar, eliminar) se
     *   propaga automáticamente a todos sus DetalleOrdenCompra asociados.
     *   Esto es exactamente lo que se necesita para el patrón
     *   maestro-detalle: al guardar una nueva orden, sus líneas de detalle
     *   se guardan automáticamente junto con ella en la misma operación.
     *
     *   orphanRemoval = true: si una línea de detalle se QUITA de esta
     *   lista en memoria (por ejemplo, al reconstruir la lista de
     *   detalles al editar una orden), Hibernate la elimina también
     *   físicamente de la base de datos, en lugar de dejarla "huérfana"
     *   apuntando a una orden que ya no la referencia.
     *
     *   fetch = FetchType.LAZY: los detalles no se cargan automáticamente
     *   al listar órdenes (por ejemplo, en la vista "ordenes/lista.html",
     *   donde solo se necesita mostrar cabecera + estado); solo se cargan
     *   cuando se accede explícitamente a ellos (por ejemplo, al mostrar
     *   el detalle completo de una orden o al recibirla).
     */
    @OneToMany(mappedBy = "ordenCompra", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<DetalleOrdenCompra> detalles = new ArrayList<>();

    public OrdenCompra() {
    }

    public OrdenCompra(String numeroOrden, LocalDate fechaEmision, Proveedor proveedor) {
        this.numeroOrden = numeroOrden;
        this.fechaEmision = fechaEmision;
        this.proveedor = proveedor;
        // Toda orden nueva nace en estado PENDIENTE y sin afectar stock.
        this.estado = EstadoOrdenCompra.PENDIENTE;
        this.total = BigDecimal.ZERO;
    }

    /**
     * Método de conveniencia que mantiene sincronizada la relación
     * bidireccional entre OrdenCompra y DetalleOrdenCompra: al agregar un
     * detalle a la orden, se agrega a la lista Y, además, se le asigna a
     * ese detalle la referencia de vuelta hacia esta misma orden
     * (detalle.setOrdenCompra(this)). Mantener ambos lados de la relación
     * sincronizados en memoria es una buena práctica fundamental al
     * trabajar con relaciones bidireccionales en JPA, para evitar
     * inconsistencias entre lo que Java "ve" en memoria y lo que
     * finalmente Hibernate persiste en la base de datos (que se basa en el
     * lado "dueño" de la relación, en este caso, el atributo
     * "ordenCompra" declarado en DetalleOrdenCompra).
     */
    public void agregarDetalle(DetalleOrdenCompra detalle) {
        detalles.add(detalle);
        detalle.setOrdenCompra(this);
    }

    // ==========================================================================
    // GETTERS Y SETTERS
    // ==========================================================================

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNumeroOrden() {
        return numeroOrden;
    }

    public void setNumeroOrden(String numeroOrden) {
        this.numeroOrden = numeroOrden;
    }

    public LocalDate getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(LocalDate fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }

    public EstadoOrdenCompra getEstado() {
        return estado;
    }

    public void setEstado(EstadoOrdenCompra estado) {
        this.estado = estado;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public List<DetalleOrdenCompra> getDetalles() {
        return detalles;
    }

    public void setDetalles(List<DetalleOrdenCompra> detalles) {
        this.detalles = detalles;
    }
}
