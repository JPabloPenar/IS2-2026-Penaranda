package com.inventario.app.repository;

import com.inventario.app.model.DetalleOrdenCompra;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * ============================================================================
 * DetalleOrdenCompraRepository
 * ============================================================================
 * Capa de acceso a datos para la entidad DetalleOrdenCompra.
 *
 * En la práctica, este proyecto gestiona la mayoría de las operaciones
 * sobre los detalles de forma INDIRECTA, a través de la relación en
 * cascada configurada en OrdenCompra (@OneToMany(cascade =
 * CascadeType.ALL)): al guardar una OrdenCompra, sus detalles se guardan
 * automáticamente con ella. Aun así, se expone este repositorio de forma
 * explícita, siguiendo la arquitectura en capas solicitada (una interfaz
 * de repositorio por cada entidad del dominio) y para dejar disponible la
 * posibilidad de realizar consultas futuras directamente sobre los
 * detalles (por ejemplo, "productos más comprados") sin tener que
 * modificar el resto de la arquitectura.
 * ============================================================================
 */
@Repository
public interface DetalleOrdenCompraRepository extends JpaRepository<DetalleOrdenCompra, Long> {
}
