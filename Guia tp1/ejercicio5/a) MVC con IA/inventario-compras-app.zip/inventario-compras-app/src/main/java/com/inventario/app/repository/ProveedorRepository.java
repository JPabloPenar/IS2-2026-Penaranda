package com.inventario.app.repository;

import com.inventario.app.model.Proveedor;
import com.inventario.app.model.enums.EstadoProveedor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * ============================================================================
 * ProveedorRepository
 * ============================================================================
 * Capa de acceso a datos para la entidad Proveedor. Al extender
 * JpaRepository<Proveedor, Long> se obtienen automáticamente (sin escribir
 * SQL) los métodos CRUD estándar: save, findById, findAll, deleteById, etc.
 *
 * @Repository: marca esta interfaz como un bean de la capa de persistencia
 * y habilita la traducción automática de excepciones de bajo nivel de
 * Hibernate/JDBC hacia la jerarquía de excepciones de Spring
 * (DataAccessException).
 * ============================================================================
 */
@Repository
public interface ProveedorRepository extends JpaRepository<Proveedor, Long> {

    /**
     * Método de consulta derivado: Spring Data JPA genera automáticamente
     * la consulta "SELECT p FROM Proveedor p WHERE p.estado = :estado" a
     * partir del propio nombre del método. Se utiliza para poblar el
     * <select> de proveedores en el formulario de nueva orden de compra,
     * mostrando ÚNICAMENTE los proveedores ACTIVOS (un proveedor INACTIVO
     * no debería poder recibir nuevas órdenes).
     */
    List<Proveedor> findByEstado(EstadoProveedor estado);

    /**
     * Verifica de forma eficiente si ya existe un proveedor con un CUIT
     * determinado, usado al validar el alta de un nuevo proveedor para
     * evitar duplicados.
     */
    boolean existsByCuit(String cuit);
}
