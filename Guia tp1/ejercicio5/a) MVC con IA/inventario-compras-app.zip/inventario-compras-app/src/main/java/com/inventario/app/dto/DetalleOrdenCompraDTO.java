package com.inventario.app.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;

import java.math.BigDecimal;

/**
 * ============================================================================
 * DetalleOrdenCompraDTO
 * ============================================================================
 * Representa UNA fila del formulario maestro-detalle de creación de
 * órdenes de compra (ordenes/formulario.html). Cada fila permite elegir un
 * producto, la cantidad solicitada y el precio unitario acordado con el
 * proveedor para esa línea.
 *
 * ¿Por qué no enlazar el formulario directamente a la entidad
 * DetalleOrdenCompra?
 *   Porque en el formulario HTML el usuario NO selecciona un objeto
 *   Producto completo, sino simplemente su "id" desde un <select>. Este
 *   DTO expone justamente ese campo simple (productoId de tipo Long), que
 *   luego la capa de servicio traduce a la entidad Producto real
 *   (buscándola por id) antes de construir el DetalleOrdenCompra
 *   definitivo. Además, permite que algunas filas del formulario queden
 *   vacías (el usuario no llenó todos los renglones disponibles) sin que
 *   eso rompa ninguna validación de la entidad JPA.
 *
 * NOTA sobre validaciones: los campos de este DTO NO llevan @NotNull
 * porque el formulario permite enviar filas completamente vacías (líneas
 * "de sobra" que el usuario no llegó a completar); es la capa de servicio
 * (OrdenCompraServiceImpl) la que filtra y descarta esas filas vacías
 * antes de construir la orden, y la que valida que, entre las filas SÍ
 * completadas, los datos sean coherentes (cantidad positiva, precio no
 * negativo, etc.).
 * ============================================================================
 */
public class DetalleOrdenCompraDTO {

    /**
     * Id del Producto elegido en el <select> de esa fila del formulario.
     * Puede llegar en null si el usuario dejó esa fila sin completar.
     */
    private Long productoId;

    /**
     * Cantidad de unidades solicitadas en esta línea.
     * @Min(1): si el valor SÍ fue completado, exige que sea al menos 1
     * (no tendría sentido una línea de compra con cantidad 0 o negativa).
     */
    @Min(value = 1, message = "La cantidad debe ser mayor a 0")
    private Integer cantidadSolicitada;

    /**
     * Precio unitario de compra acordado con el proveedor para esta línea.
     * @DecimalMin("0.0"): si fue completado, no puede ser negativo
     * (inclusive = false excluye exactamente 0.0, ya que un precio de
     * compra igual a cero normalmente no sería un dato válido de negocio).
     */
    @DecimalMin(value = "0.0", inclusive = false, message = "El precio unitario debe ser mayor a 0")
    private BigDecimal precioUnitarioCompra;

    public DetalleOrdenCompraDTO() {
    }

    /**
     * Indica si esta fila del formulario fue efectivamente completada por
     * el usuario (tiene un producto seleccionado). Se usa en la capa de
     * servicio para descartar las filas "vacías" sobrantes del formulario
     * antes de construir la orden.
     */
    public boolean estaCompleta() {
        return productoId != null && cantidadSolicitada != null && precioUnitarioCompra != null;
    }

    public Long getProductoId() {
        return productoId;
    }

    public void setProductoId(Long productoId) {
        this.productoId = productoId;
    }

    public Integer getCantidadSolicitada() {
        return cantidadSolicitada;
    }

    public void setCantidadSolicitada(Integer cantidadSolicitada) {
        this.cantidadSolicitada = cantidadSolicitada;
    }

    public BigDecimal getPrecioUnitarioCompra() {
        return precioUnitarioCompra;
    }

    public void setPrecioUnitarioCompra(BigDecimal precioUnitarioCompra) {
        this.precioUnitarioCompra = precioUnitarioCompra;
    }
}
