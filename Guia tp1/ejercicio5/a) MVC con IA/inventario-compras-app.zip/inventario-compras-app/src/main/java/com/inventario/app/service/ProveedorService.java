package com.inventario.app.service;

import com.inventario.app.model.Proveedor;

import java.util.List;

/**
 * ============================================================================
 * ProveedorService (Interfaz)
 * ============================================================================
 * Contrato de la capa de negocio para la gestión de proveedores. Los
 * controladores dependen de esta interfaz, no de su implementación
 * concreta (ver ProveedorServiceImpl), siguiendo el principio de
 * "programar contra interfaces".
 * ============================================================================
 */
public interface ProveedorService {

    /** Devuelve todos los proveedores registrados (activos e inactivos). */
    List<Proveedor> listarTodos();

    /**
     * Devuelve únicamente los proveedores en estado ACTIVO, usados para
     * poblar el <select> del formulario de nueva orden de compra (no
     * tendría sentido emitirle una orden a un proveedor inactivo).
     */
    List<Proveedor> listarActivos();

    /** Busca un proveedor por su id, lanzando una excepción si no existe. */
    Proveedor buscarPorId(Long id);
}
