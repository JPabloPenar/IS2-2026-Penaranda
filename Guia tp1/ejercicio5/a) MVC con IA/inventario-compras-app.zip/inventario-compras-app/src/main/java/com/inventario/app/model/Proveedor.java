package com.inventario.app.model;

import com.inventario.app.model.enums.EstadoProveedor;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * ============================================================================
 * Proveedor (Entidad JPA)
 * ============================================================================
 * Representa a un proveedor mayorista al cual la empresa le realiza
 * órdenes de compra para reponer stock. Es una de las cuatro entidades
 * centrales del dominio, junto con Producto, OrdenCompra y
 * DetalleOrdenCompra.
 *
 * @Entity + @Table(name = "proveedores"):
 *   Ver explicación general de estas anotaciones en Producto.java (se
 *   repite el mismo mecanismo de mapeo objeto-relacional para todas las
 *   entidades del proyecto).
 * ============================================================================
 */
@Entity
@Table(name = "proveedores")
public class Proveedor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * CUIT/RUT del proveedor (identificador fiscal). unique = true: no
     * puede haber dos proveedores registrados con el mismo número fiscal.
     */
    @Column(nullable = false, unique = true, length = 20)
    private String cuit;

    /** Razón social (nombre legal/comercial) del proveedor. */
    @Column(nullable = false, length = 150)
    private String razonSocial;

    @Column(length = 30)
    private String telefono;

    @Column(name = "correo_contacto", length = 150)
    private String correoContacto;

    /**
     * @Enumerated(EnumType.STRING):
     *   Le indica a Hibernate CÓMO debe almacenar el valor del enum
     *   EstadoProveedor en la base de datos. Con EnumType.STRING se
     *   guarda el NOMBRE textual de la constante ("ACTIVO", "INACTIVO"),
     *   en lugar de EnumType.ORDINAL (que guardaría un simple número: 0,
     *   1...). Se prefiere STRING porque es mucho más legible al inspeccionar
     *   la base de datos directamente y, sobre todo, porque es resistente a
     *   refactors: si en el futuro se reordena o se agrega una constante
     *   al enum, los datos ya almacenados con ORDINAL podrían quedar mal
     *   interpretados, mientras que con STRING el valor guardado sigue
     *   siendo válido mientras el nombre de la constante no cambie.
     */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private EstadoProveedor estado;

    public Proveedor() {
    }

    public Proveedor(String cuit, String razonSocial, String telefono, String correoContacto) {
        this.cuit = cuit;
        this.razonSocial = razonSocial;
        this.telefono = telefono;
        this.correoContacto = correoContacto;
        // Todo proveedor nuevo se da de alta como ACTIVO por defecto.
        this.estado = EstadoProveedor.ACTIVO;
    }

    // ==========================================================================
    // GETTERS Y SETTERS (convención JavaBean requerida por JPA/Hibernate y
    // por el data binding de formularios de Spring MVC/Thymeleaf).
    // ==========================================================================

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreoContacto() {
        return correoContacto;
    }

    public void setCorreoContacto(String correoContacto) {
        this.correoContacto = correoContacto;
    }

    public EstadoProveedor getEstado() {
        return estado;
    }

    public void setEstado(EstadoProveedor estado) {
        this.estado = estado;
    }
}
