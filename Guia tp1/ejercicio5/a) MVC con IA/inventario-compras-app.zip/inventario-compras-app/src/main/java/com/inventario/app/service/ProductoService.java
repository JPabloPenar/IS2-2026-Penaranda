package com.inventario.app.service;

import com.inventario.app.model.Producto;

import java.math.BigDecimal;
import java.util.List;

/**
 * ============================================================================
 * ProductoService (Interfaz)
 * ============================================================================
 * Contrato de la capa de negocio para la gestión del catálogo de
 * productos y su información de inventario.
 * ============================================================================
 */
public interface ProductoService {

    /** Devuelve el catálogo completo de productos. */
    List<Producto> listarTodos();

    /**
     * Devuelve únicamente los productos cuyo stockActual está en el
     * umbral crítico (por debajo o igual a su stockMinimo).
     */
    List<Producto> listarStockCritico();

    /** Cantidad total de productos en stock crítico (para el dashboard). */
    long contarStockCritico();

    /**
     * Valor monetario total del inventario actual, calculado como la
     * sumatoria de (precioCosto * stockActual) de todos los productos.
     */
    BigDecimal calcularValorTotalInventario();

    /** Busca un producto por su id, lanzando una excepción si no existe. */
    Producto buscarPorId(Long id);
}
