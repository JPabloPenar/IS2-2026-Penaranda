package com.inventario.app.model.enums;

/**
 * ============================================================================
 * EstadoOrdenCompra (Enumeración)
 * ============================================================================
 * Representa los tres posibles estados por los que puede pasar una Orden de
 * Compra a lo largo de su ciclo de vida. Usar un "enum" en lugar de un
 * simple String ("PENDIENTE", "RECIBIDA", etc.) tiene ventajas muy
 * importantes:
 *
 *   1) Seguridad de tipos en tiempo de compilación: es imposible asignarle
 *      a una OrdenCompra un estado que no exista (el compilador lo
 *      impediría), a diferencia de un String donde un simple error de
 *      tipeo ("PENDIENTEE") pasaría desapercibido hasta ejecutarse.
 *
 *   2) Los operadores de comparación (==, switch) son más seguros, legibles
 *      y eficientes que comparar Strings con .equals().
 *
 *   3) Documenta explícitamente, en un único lugar, cuáles son TODOS los
 *      estados válidos del dominio de negocio.
 *
 * Flujo de negocio de este enum (ver PASO A PASO en
 * OrdenCompraServiceImpl.recibirOrden(...) y .cancelarOrden(...)):
 *
 *   PENDIENTE  --(recibir mercadería)-->  RECIBIDA   (estado final, bloqueado)
 *   PENDIENTE  --(cancelar)-->            CANCELADA  (estado final, bloqueado)
 *
 * Una vez que una orden pasa a RECIBIDA o CANCELADA, no puede volver a
 * PENDIENTE ni transicionar a ningún otro estado: ambos son estados
 * "terminales" para efectos de edición.
 * ============================================================================
 */
public enum EstadoOrdenCompra {

    /**
     * Estado inicial de toda orden recién creada. En este estado la orden
     * puede editarse o cancelarse libremente, y NO afecta todavía el stock
     * de los productos ni su precio de costo.
     */
    PENDIENTE,

    /**
     * Estado al que se transiciona cuando el encargado de depósito
     * confirma que la mercadería fue efectivamente recibida del
     * proveedor. Al llegar a este estado (ver
     * OrdenCompraServiceImpl.recibirOrden), se dispara automáticamente el
     * incremento de stock y la actualización del precio de costo de cada
     * producto involucrado. Es un estado FINAL: la orden queda bloqueada
     * para edición o cancelación posterior.
     */
    RECIBIDA,

    /**
     * Estado al que se transiciona cuando se decide no continuar con una
     * orden que todavía estaba PENDIENTE (por ejemplo, el proveedor no
     * puede cumplir la entrega). No afecta el stock. Es también un estado
     * FINAL.
     */
    CANCELADA
}
