package com.inventario.app.service.impl;

import com.inventario.app.dto.DetalleOrdenCompraDTO;
import com.inventario.app.dto.OrdenCompraDTO;
import com.inventario.app.model.DetalleOrdenCompra;
import com.inventario.app.model.OrdenCompra;
import com.inventario.app.model.Producto;
import com.inventario.app.model.Proveedor;
import com.inventario.app.model.enums.EstadoOrdenCompra;
import com.inventario.app.repository.OrdenCompraRepository;
import com.inventario.app.repository.ProductoRepository;
import com.inventario.app.repository.ProveedorRepository;
import com.inventario.app.service.OrdenCompraService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * ============================================================================
 * OrdenCompraServiceImpl
 * ============================================================================
 * Corazón de la lógica de negocio del sistema: gestiona la creación de
 * órdenes de compra y, sobre todo, el proceso transaccional de recepción
 * de mercadería que actualiza automáticamente el stock e implementa el
 * bloqueo de órdenes ya finalizadas.
 *
 * @Service: marca esta clase como un bean de la capa de negocio,
 * inyectable en los controladores.
 * ============================================================================
 */
@Service
public class OrdenCompraServiceImpl implements OrdenCompraService {

    private final OrdenCompraRepository ordenCompraRepository;
    private final ProveedorRepository proveedorRepository;
    private final ProductoRepository productoRepository;

    /**
     * Prefijo utilizado para construir el número de orden "legible"
     * (ej. "ORD-000001"), combinado con el id autogenerado de la entidad.
     */
    private static final String PREFIJO_NUMERO_ORDEN = "ORD-";

    public OrdenCompraServiceImpl(OrdenCompraRepository ordenCompraRepository,
                                   ProveedorRepository proveedorRepository,
                                   ProductoRepository productoRepository) {
        this.ordenCompraRepository = ordenCompraRepository;
        this.proveedorRepository = proveedorRepository;
        this.productoRepository = productoRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<OrdenCompra> listarTodas() {
        return ordenCompraRepository.findAllByOrderByFechaEmisionDesc();
    }

    @Override
    @Transactional(readOnly = true)
    public OrdenCompra buscarPorId(Long id) {
        return ordenCompraRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("No existe una orden de compra con id: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public long contarPendientes() {
        return ordenCompraRepository.countByEstado(EstadoOrdenCompra.PENDIENTE);
    }

    /**
     * {@inheritDoc}
     *
     * PASO A PASO de la creación de una orden de compra:
     *
     *   1) Se busca la entidad Proveedor real a partir del proveedorId
     *      recibido en el DTO (el formulario solo envía el id, no el
     *      objeto completo).
     *
     *   2) Se construye la entidad OrdenCompra "cabecera" en estado
     *      PENDIENTE, con un número de orden provisorio (se recalcula el
     *      número de orden definitivo recién DESPUÉS del primer save,
     *      cuando ya se conoce el id autogenerado; ver más abajo).
     *
     *   3) Se recorre cada línea del DTO de detalle:
     *        - Se descartan las filas que el usuario dejó vacías
     *          (dto.estaCompleta() == false), ya que el formulario ofrece
     *          más renglones de los que el usuario necesariamente
     *          completa.
     *        - Para cada fila completa, se busca el Producto real a
     *          partir de su id, se calcula el subtotal
     *          (cantidad * precioUnitario) y se construye el
     *          DetalleOrdenCompra correspondiente, vinculándolo a la
     *          orden mediante orden.agregarDetalle(...) (método que
     *          mantiene sincronizados ambos lados de la relación
     *          bidireccional).
     *        - Se acumula el total general de la orden sumando cada
     *          subtotal.
     *
     *   4) Se asigna el total calculado a la orden y se persiste. Gracias
     *      a CascadeType.ALL configurado en OrdenCompra.detalles, un único
     *      llamado a ordenCompraRepository.save(orden) persiste, en la
     *      misma operación, tanto la cabecera como TODAS sus líneas de
     *      detalle.
     *
     * @Transactional:
     *   Si cualquier paso de este proceso fallara (por ejemplo, un
     *   productoId inexistente en alguna fila), Spring revierte
     *   automáticamente cualquier cambio parcial ya aplicado, evitando
     *   dejar en la base de datos una orden a medio construir.
     */
    @Override
    @Transactional
    public OrdenCompra crearOrden(OrdenCompraDTO dto) {

        // Paso 1: resolver el Proveedor real a partir de su id.
        Proveedor proveedor = proveedorRepository.findById(dto.getProveedorId())
                .orElseThrow(() -> new NoSuchElementException(
                        "No existe un proveedor con id: " + dto.getProveedorId()));

        // Paso 2: construir la cabecera de la orden en estado PENDIENTE.
        // El número de orden definitivo se completa más abajo, una vez
        // que la orden ya tiene un id asignado por la base de datos.
        OrdenCompra orden = new OrdenCompra("PROVISORIO", dto.getFechaEmision(), proveedor);

        // Paso 3: recorrer cada línea del formulario y construir los
        // detalles correspondientes, acumulando el total general.
        BigDecimal totalOrden = BigDecimal.ZERO;

        for (DetalleOrdenCompraDTO detalleDTO : dto.getDetalles()) {

            // Se ignoran las filas del formulario que el usuario dejó
            // vacías (renglones "de sobra" no completados).
            if (!detalleDTO.estaCompleta()) {
                continue;
            }

            Producto producto = productoRepository.findById(detalleDTO.getProductoId())
                    .orElseThrow(() -> new NoSuchElementException(
                            "No existe un producto con id: " + detalleDTO.getProductoId()));

            DetalleOrdenCompra detalle = new DetalleOrdenCompra(
                    producto,
                    detalleDTO.getCantidadSolicitada(),
                    detalleDTO.getPrecioUnitarioCompra()
            );

            // Vincula el detalle con la orden y mantiene sincronizada la
            // relación bidireccional (ver OrdenCompra.agregarDetalle).
            orden.agregarDetalle(detalle);

            // Acumula el subtotal de esta línea al total general de la orden.
            totalOrden = totalOrden.add(detalle.getSubtotal());
        }

        orden.setTotal(totalOrden);

        // Primer guardado: persiste la orden (y, en cascada, sus
        // detalles) y permite que la base de datos le asigne su id
        // autogenerado, necesario para construir el número de orden legible.
        OrdenCompra ordenGuardada = ordenCompraRepository.save(orden);

        // Se completa el número de orden definitivo combinando el
        // prefijo fijo con el id ya asignado, con relleno de ceros a la
        // izquierda hasta 6 dígitos (ej.: id=7 -> "ORD-000007").
        ordenGuardada.setNumeroOrden(PREFIJO_NUMERO_ORDEN + String.format("%06d", ordenGuardada.getId()));

        // Segundo guardado: actualiza únicamente el campo numeroOrden ya
        // calculado (Hibernate detecta el cambio sobre la entidad ya
        // gestionada y genera un UPDATE, no vuelve a insertar los detalles).
        return ordenCompraRepository.save(ordenGuardada);
    }

    /**
     * {@inheritDoc}
     *
     * PASO A PASO de la recepción de mercadería (regla de negocio central
     * del sistema):
     *
     *   1) Se busca la orden por su id.
     *
     *   2) Se valida que la orden se encuentre en estado PENDIENTE. Si ya
     *      fue RECIBIDA o CANCELADA anteriormente, se rechaza la
     *      operación lanzando una IllegalStateException: una orden
     *      RECIBIDA queda bloqueada para nuevas ediciones (no se puede
     *      "recibir dos veces" y así duplicar el incremento de stock), y
     *      una orden CANCELADA nunca debería poder recibirse.
     *
     *   3) Se recorre CADA línea de detalle de la orden y, para el
     *      Producto asociado a esa línea:
     *        a) Se incrementa su stockActual sumándole la
     *           cantidadSolicitada de esa línea
     *           (stockActual = stockActual + cantidad).
     *        b) Se actualiza su precioCosto con el precioUnitarioCompra
     *           acordado en esa línea (el costo "oficial" del producto
     *           pasa a reflejar el último precio realmente pagado al
     *           proveedor).
     *        c) Se persiste el Producto actualizado.
     *
     *   4) Se transiciona el estado de la orden a RECIBIDA y se persiste.
     *
     * @Transactional (SIN readOnly, ya que este método SÍ modifica
     * datos):
     *   Esta anotación es CRÍTICA para el requisito de "rollback completo
     *   si falla algún ítem": todo el bucle de actualización de stock del
     *   paso 3, más el cambio de estado del paso 4, se ejecutan dentro de
     *   UNA ÚNICA transacción de base de datos. Si, por ejemplo, el
     *   tercer producto de una orden con cinco líneas lanzara una
     *   excepción inesperada al actualizarse, Spring revierte
     *   AUTOMÁTICAMENTE (rollback) los cambios de stock ya aplicados a
     *   los dos productos anteriores dentro de ese mismo método, dejando
     *   la base de datos exactamente como estaba antes de intentar
     *   recibir la orden (ningún incremento de stock "a medias"). Sin
     *   esta anotación, cada llamado a productoRepository.save(...)
     *   podría comportarse como una operación independiente, arriesgando
     *   dejar el inventario en un estado inconsistente ante un fallo
     *   parcial.
     */
    @Override
    @Transactional
    public OrdenCompra recibirOrden(Long id) {

        // Paso 1: buscar la orden.
        OrdenCompra orden = ordenCompraRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("No existe una orden de compra con id: " + id));

        // Paso 2: validar que la orden esté en estado PENDIENTE. Una
        // orden ya RECIBIDA o CANCELADA queda bloqueada para este proceso.
        if (orden.getEstado() != EstadoOrdenCompra.PENDIENTE) {
            throw new IllegalStateException(
                    "Solo se pueden recibir órdenes en estado PENDIENTE. Estado actual: " + orden.getEstado());
        }

        // Paso 3: recorrer cada línea de detalle y aplicar el impacto en
        // stock y precio de costo sobre el Producto correspondiente.
        for (DetalleOrdenCompra detalle : orden.getDetalles()) {
            Producto producto = detalle.getProducto();

            // 3.a) Incrementar el stock actual del producto con la
            // cantidad efectivamente solicitada/recibida en esta línea.
            int stockNuevo = producto.getStockActual() + detalle.getCantidadSolicitada();
            producto.setStockActual(stockNuevo);

            // 3.b) Actualizar el precio de costo del producto con el
            // precio unitario realmente pagado en esta compra.
            producto.setPrecioCosto(detalle.getPrecioUnitarioCompra());

            // 3.c) Persistir el producto actualizado.
            productoRepository.save(producto);
        }

        // Paso 4: transicionar la orden al estado final RECIBIDA.
        orden.setEstado(EstadoOrdenCompra.RECIBIDA);
        return ordenCompraRepository.save(orden);
    }

    /**
     * {@inheritDoc}
     *
     * Solo se permite cancelar órdenes que todavía estén PENDIENTES. Si
     * la orden ya fue RECIBIDA, queda bloqueada para cancelación (el
     * enunciado exige explícitamente que una orden RECIBIDA quede
     * bloqueada para edición o cancelación posterior, ya que cancelar una
     * orden que ya impactó el stock dejaría el inventario en un estado
     * incoherente sin revertir manualmente esos incrementos).
     */
    @Override
    @Transactional
    public OrdenCompra cancelarOrden(Long id) {
        OrdenCompra orden = ordenCompraRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("No existe una orden de compra con id: " + id));

        if (orden.getEstado() != EstadoOrdenCompra.PENDIENTE) {
            throw new IllegalStateException(
                    "Solo se pueden cancelar órdenes en estado PENDIENTE. Estado actual: " + orden.getEstado());
        }

        orden.setEstado(EstadoOrdenCompra.CANCELADA);
        return ordenCompraRepository.save(orden);
    }
}
