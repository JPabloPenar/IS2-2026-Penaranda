package com.inventario.app.controller;

import com.inventario.app.dto.DetalleOrdenCompraDTO;
import com.inventario.app.dto.OrdenCompraDTO;
import com.inventario.app.service.OrdenCompraService;
import com.inventario.app.service.ProductoService;
import com.inventario.app.service.ProveedorService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;

/**
 * ============================================================================
 * OrdenCompraController
 * ============================================================================
 * Controlador central del flujo de compras: listar órdenes existentes,
 * mostrar y procesar el formulario maestro-detalle de creación, y
 * gestionar las acciones de "Recibir Orden" y "Cancelar Orden".
 * ============================================================================
 */
@Controller
public class OrdenCompraController {

    /** Cantidad de filas vacías que se precargan en el formulario de nueva orden. */
    private static final int FILAS_INICIALES_DETALLE = 5;

    private final OrdenCompraService ordenCompraService;
    private final ProveedorService proveedorService;
    private final ProductoService productoService;

    public OrdenCompraController(OrdenCompraService ordenCompraService,
                                  ProveedorService proveedorService,
                                  ProductoService productoService) {
        this.ordenCompraService = ordenCompraService;
        this.proveedorService = proveedorService;
        this.productoService = productoService;
    }

    /**
     * Muestra el listado de todas las órdenes de compra, con su estado
     * actual y el botón de acción correspondiente (recibir/cancelar)
     * según ese estado.
     */
    @GetMapping("/ordenes")
    public String listarOrdenes(Model model) {
        model.addAttribute("ordenes", ordenCompraService.listarTodas());
        return "ordenes/lista";
    }

    /**
     * Muestra el formulario maestro-detalle para crear una nueva orden de
     * compra.
     *
     * @ModelAttribute mecanismo: se agrega directamente al Model un
     * OrdenCompraDTO precargado con la fecha de hoy y una cantidad fija
     * de filas de detalle vacías (FILAS_INICIALES_DETALLE), de forma que
     * la plantilla pueda recorrerlas con th:each y generar los campos
     * indexados (detalles[0], detalles[1], ...) sin arrojar un error de
     * "índice fuera de rango" si el usuario no llega a completarlas todas.
     */
    @GetMapping("/ordenes/nueva")
    public String mostrarFormularioNuevaOrden(Model model) {
        OrdenCompraDTO dto = new OrdenCompraDTO();
        dto.setFechaEmision(LocalDate.now());

        // Se precargan filas vacías de detalle: el usuario completará
        // tantas como necesite y dejará el resto en blanco (esas filas
        // vacías se descartan automáticamente en
        // OrdenCompraServiceImpl.crearOrden).
        for (int i = 0; i < FILAS_INICIALES_DETALLE; i++) {
            dto.getDetalles().add(new DetalleOrdenCompraDTO());
        }

        model.addAttribute("ordenCompraDTO", dto);
        // Se exponen los proveedores ACTIVOS y todo el catálogo de
        // productos para poblar los <select> del formulario.
        model.addAttribute("proveedores", proveedorService.listarActivos());
        model.addAttribute("productos", productoService.listarTodos());
        return "ordenes/formulario";
    }

    /**
     * Procesa el envío del formulario de nueva orden de compra.
     *
     * @Valid sobre OrdenCompraDTO, combinado con @Valid en el propio
     * campo "detalles" de esa clase, dispara la validación en cascada:
     * primero se validan proveedorId/fechaEmision, y luego, línea por
     * línea, los campos de cada DetalleOrdenCompraDTO (cantidad mínima,
     * precio mínimo) para las filas que el usuario sí completó.
     */
    @PostMapping("/ordenes")
    public String procesarNuevaOrden(@ModelAttribute("ordenCompraDTO") @Valid OrdenCompraDTO ordenCompraDTO,
                                      BindingResult bindingResult,
                                      Model model,
                                      RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            // Se vuelve a mostrar el formulario con los errores. Es
            // necesario recargar nuevamente las listas de proveedores y
            // productos en el modelo, ya que este método POST no las
            // recibe automáticamente (a diferencia del GET inicial).
            model.addAttribute("proveedores", proveedorService.listarActivos());
            model.addAttribute("productos", productoService.listarTodos());
            return "ordenes/formulario";
        }

        var ordenCreada = ordenCompraService.crearOrden(ordenCompraDTO);

        // RedirectAttributes.addFlashAttribute(...):
        //   Permite pasar un mensaje "de un solo uso" a la página a la
        //   que se redirige (patrón Post-Redirect-Get). A diferencia de
        //   agregar el atributo al Model normal (que solo sobrevive
        //   mientras se renderiza la vista actual), un "flash attribute"
        //   sobrevive exactamente UNA redirección HTTP, ideal para
        //   mensajes de éxito/error que deben mostrarse en la página
        //   siguiente y luego desaparecer si el usuario refresca.
        redirectAttributes.addFlashAttribute("mensajeExito",
                "Orden de compra " + ordenCreada.getNumeroOrden() + " creada correctamente.");

        return "redirect:/ordenes";
    }

    /**
     * Procesa la acción "Recibir Orden" desde el listado de órdenes.
     *
     * @PathVariable Long id:
     *   Extrae el segmento "{id}" de la URL (por ejemplo,
     *   "/ordenes/7/recibir" -> id = 7L) y lo enlaza automáticamente con
     *   el parámetro del método, permitiendo referenciar dinámicamente
     *   una orden concreta sin tener que leer manualmente los parámetros
     *   de la petición.
     *
     * RedirectAttributes:
     *   Se usa tanto para el mensaje de éxito como para comunicar,
     *   mediante un mensaje de error "flash", el motivo por el cual la
     *   operación pudo haber sido rechazada (por ejemplo, si la orden ya
     *   había sido recibida o cancelada previamente).
     */
    @PostMapping("/ordenes/{id}/recibir")
    public String recibirOrden(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            var orden = ordenCompraService.recibirOrden(id);
            redirectAttributes.addFlashAttribute("mensajeExito",
                    "Orden " + orden.getNumeroOrden() + " marcada como RECIBIDA. Stock actualizado correctamente.");
        } catch (IllegalStateException ex) {
            // Se captura la excepción de negocio lanzada por el servicio
            // cuando se intenta recibir una orden que no está PENDIENTE,
            // y se traduce en un mensaje de error amigable para el
            // usuario, en lugar de dejar que se propague como un error
            // HTTP 500 genérico.
            redirectAttributes.addFlashAttribute("mensajeError", ex.getMessage());
        }
        return "redirect:/ordenes";
    }

    /** Procesa la acción "Cancelar Orden" desde el listado de órdenes. */
    @PostMapping("/ordenes/{id}/cancelar")
    public String cancelarOrden(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            var orden = ordenCompraService.cancelarOrden(id);
            redirectAttributes.addFlashAttribute("mensajeExito",
                    "Orden " + orden.getNumeroOrden() + " cancelada correctamente.");
        } catch (IllegalStateException ex) {
            redirectAttributes.addFlashAttribute("mensajeError", ex.getMessage());
        }
        return "redirect:/ordenes";
    }
}
