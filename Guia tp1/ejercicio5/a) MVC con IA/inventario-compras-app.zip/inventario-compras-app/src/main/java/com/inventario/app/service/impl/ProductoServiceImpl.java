package com.inventario.app.service.impl;

import com.inventario.app.model.Producto;
import com.inventario.app.repository.ProductoRepository;
import com.inventario.app.service.ProductoService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * ============================================================================
 * ProductoServiceImpl
 * ============================================================================
 * Implementación de la lógica de negocio relacionada con el catálogo de
 * productos y sus indicadores de inventario.
 * ============================================================================
 */
@Service
public class ProductoServiceImpl implements ProductoService {

    private final ProductoRepository productoRepository;

    public ProductoServiceImpl(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Producto> listarTodos() {
        return productoRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Producto> listarStockCritico() {
        return productoRepository.findProductosConStockCritico();
    }

    @Override
    @Transactional(readOnly = true)
    public long contarStockCritico() {
        return productoRepository.contarProductosConStockCritico();
    }

    @Override
    @Transactional(readOnly = true)
    public BigDecimal calcularValorTotalInventario() {
        return productoRepository.calcularValorTotalInventario();
    }

    @Override
    @Transactional(readOnly = true)
    public Producto buscarPorId(Long id) {
        return productoRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("No existe un producto con id: " + id));
    }
}
